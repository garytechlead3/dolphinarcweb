const MainLayout = ({ children }: any) => {
    return <main>{children}</main>
}

export default MainLayout
